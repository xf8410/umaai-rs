#!/usr/bin/env bash
# 用法: bash logs/r3roll/worker.sh <0|1>
set -u
W="$1"
cd /workspace/umaai-rs-muxue
source logs/r3roll/deadline.env
BASE=9500000; SEG_LEN=3100; HALF=1550; CHUNK=128; NSEG=3
EV=logs/r3roll/worker_p${W}.events
for SEG in $(seq 1 $NSEG); do
  SEG_START=$(( BASE + (SEG - 1) * SEG_LEN + W * HALF ))
  DIR=$(printf "training_data/r3roll_s%02d_p%d" "$SEG" "$W")
  LOG=logs/r3roll/$(basename "$DIR").log
  CUM=0
  if [ -f "$DIR/manifest.json" ]; then
    CUM=$(python3 -c "import json,sys; m=json.load(open(sys.argv[1])); print(m['next_index'] - m['index_start'])" "$DIR/manifest.json")
  fi
  while [ "$CUM" -lt "$HALF" ]; do
    NOW=$(date +%s)
    if [ -e logs/r3roll/STOP ]; then
      echo "$(TZ=Asia/Tokyo date -Iseconds) STOP 文件存在，停止派发（$DIR 已到 $CUM/$HALF）" >> "$EV"; exit 0
    fi
    if [ "$NOW" -ge "$CUTOFF_EPOCH" ]; then
      echo "$(TZ=Asia/Tokyo date -Iseconds) 到达派发截止，停止派发（$DIR 已到 $CUM/$HALF）" >> "$EV"; exit 0
    fi
    NEXT=$(( CUM + CHUNK )); [ "$NEXT" -gt "$HALF" ] && NEXT=$HALF
    echo "$(TZ=Asia/Tokyo date -Iseconds) 开始 $DIR --start $SEG_START --count $NEXT" >> "$EV"
    RAYON_NUM_THREADS=4 ./target/release/ramen_teacher_collect \
      --rollin nn --model saved_models/arms/ens_R3full_g123.onnx --search-n 1024 \
      --start "$SEG_START" --count "$NEXT" --output-dir "$DIR" --shard-size 32 \
      --radical-factor-max 1.4 --region-quota-permille 20,30 >> "$LOG" 2>&1
    RC=$?
    echo "$(TZ=Asia/Tokyo date -Iseconds) 结束 $DIR rc=$RC" >> "$EV"
    if [ "$RC" -ne 0 ]; then
      echo "$(TZ=Asia/Tokyo date -Iseconds) 采集器非零退出，本 worker 停止" >> "$EV"; exit 1
    fi
    CUM=$(python3 -c "import json,sys; m=json.load(open(sys.argv[1])); print(m['next_index'] - m['index_start'])" "$DIR/manifest.json")
  done
done
echo "$(TZ=Asia/Tokyo date -Iseconds) 3 段全部完成" >> "$EV"
