#!/usr/bin/env bash
set -eu
cd /workspace/umaai-rs-muxue
mkdir -p logs/r4roll2
for d in training_data/r4roll2_s01_p0 training_data/r4roll2_s01_p1 training_data/r4roll2_s02_p0 training_data/r4roll2_s02_p1 training_data/r4roll2_s03_p0 training_data/r4roll2_s03_p1; do
  test ! -e "$d" || { echo EXISTS "$d"; exit 1; }
done
test ! -e logs/r4roll2/STOP
test -x target/r5_collect_07c4868/release/ramen_teacher_collect
START_EPOCH=$(date +%s)
CUTOFF_EPOCH=$(( START_EPOCH + 86400*30 ))
cat > logs/r4roll2/deadline.env <<E
START_EPOCH=$START_EPOCH
DEADLINE_EPOCH=$CUTOFF_EPOCH
CUTOFF_EPOCH=$CUTOFF_EPOCH
E
{
  echo "start_jst=$(TZ=Asia/Tokyo date -d @$START_EPOCH -Iseconds)"
  echo "model=saved_models/arms/ens_R4_g123.onnx"
  echo "rollin_expected=nn:741d02fc29a395d9"
  echo "search_n=1024 git=$(git rev-parse HEAD)"
  echo "bin=target/r5_collect_07c4868/release/ramen_teacher_collect"
  echo "indexes=10000 band=9610300-9620299 note=second_wave_after_r4roll"
} > logs/r4roll2/run_meta.txt
nohup vmstat 30 > logs/r4roll2/vmstat.txt 2>&1 &
echo $! > logs/r4roll2/vmstat.pid
nohup /usr/bin/time -v -o logs/r4roll2/worker_p0_time.txt bash logs/r4roll2/worker.sh 0 > logs/r4roll2/worker_p0.out 2>&1 &
echo $! > logs/r4roll2/worker_p0.pid
nohup /usr/bin/time -v -o logs/r4roll2/worker_p1_time.txt bash logs/r4roll2/worker.sh 1 > logs/r4roll2/worker_p1.out 2>&1 &
echo $! > logs/r4roll2/worker_p1.pid
cat logs/r4roll2/run_meta.txt
echo STARTED_PIDS $(cat logs/r4roll2/worker_p0.pid) $(cat logs/r4roll2/worker_p1.pid)
