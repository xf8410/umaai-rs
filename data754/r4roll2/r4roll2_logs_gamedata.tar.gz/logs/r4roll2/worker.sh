#!/usr/bin/env bash
# 用法: bash logs/r4roll2/worker.sh <0|1>
set -u
W="$1"
cd /workspace/umaai-rs-muxue
source logs/r4roll2/deadline.env
BIN=./target/r5_collect_07c4868/release/ramen_teacher_collect
CHUNK=128
EV=logs/r4roll2/worker_p${W}.events
if [ "$W" = "0" ]; then
  SEGS=(
    "training_data/r4roll2_s01_p0 9610300 1700"
    "training_data/r4roll2_s02_p0 9613700 1700"
    "training_data/r4roll2_s03_p0 9617100 1600"
  )
else
  SEGS=(
    "training_data/r4roll2_s01_p1 9612000 1700"
    "training_data/r4roll2_s02_p1 9615400 1700"
    "training_data/r4roll2_s03_p1 9618700 1600"
  )
fi
for SPEC in "${SEGS[@]}"; do
  set -- $SPEC
  DIR=$1; SEG_START=$2; HALF=$3
  LOG=logs/r4roll2/$(basename "$DIR").log
  CUM=0
  if [ -f "$DIR/manifest.json" ]; then
    CUM=$(python3 -c "import json,sys; m=json.load(open(sys.argv[1])); print(m['next_index'] - m['index_start'])" "$DIR/manifest.json")
  fi
  while [ "$CUM" -lt "$HALF" ]; do
    if [ -e logs/r4roll2/STOP ]; then
      echo "$(TZ=Asia/Tokyo date -Iseconds) STOP 文件存在，停止派发（$DIR 已到 $CUM/$HALF）" >> "$EV"; exit 0
    fi
    NEXT=$(( CUM + CHUNK )); [ "$NEXT" -gt "$HALF" ] && NEXT=$HALF
    echo "$(TZ=Asia/Tokyo date -Iseconds) 开始 $DIR --start $SEG_START --count $NEXT" >> "$EV"
    RAYON_NUM_THREADS=4 "$BIN" \
      --rollin nn --model saved_models/arms/ens_R4_g123.onnx --search-n 1024 \
      --start "$SEG_START" --count "$NEXT" --output-dir "$DIR" --shard-size 32 \
      --radical-factor-max 1.4 --region-quota-permille 20,30 >> "$LOG" 2>&1
    RC=$?
    echo "$(TZ=Asia/Tokyo date -Iseconds) 结束 $DIR rc=$RC" >> "$EV"
    if [ "$RC" -ne 0 ]; then
      echo "$(TZ=Asia/Tokyo date -Iseconds) 采集器非零退出，本 worker 停止" >> "$EV"; exit 1
    fi
    CUM=$(python3 -c "import json,sys; m=json.load(open(sys.argv[1])); print(m['next_index'] - m['index_start'])" "$DIR/manifest.json")
  done
done
echo "$(TZ=Asia/Tokyo date -Iseconds) 全部目录完成" >> "$EV"
